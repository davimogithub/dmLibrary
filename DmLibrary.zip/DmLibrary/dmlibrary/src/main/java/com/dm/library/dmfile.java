package com.dm.library;

import android.content.*;
import android.widget.*;
import java.io.*;
import android.os.*;
import org.json.*;
import android.graphics.*;

public class dmfile
{
   
	private static String text_data;
	private static String image_data;
	private static Bitmap bitmap_data;

	
	public void readDmfile(String p, TextView tv,ImageView img) 
	{    
		StringBuilder stringBuilder = new StringBuilder();
		try {
			BufferedReader bufferedReader = new BufferedReader(new FileReader(p));
			String line;
			while ((line = bufferedReader.readLine()) != null) {
				stringBuilder.append(line);
				stringBuilder.append('\n');
			}
			bufferedReader.close();
		} catch (IOException e) {
			
		}
		
		try{  
			JSONObject reader = new JSONObject(stringBuilder.toString());
			text_data = reader.getString("cm");
			image_data = reader.getString("data");
		}catch(Exception e)
		{}
		TextView text = tv;
		text.setText(text_data);
		try{
			byte[] decodedString = android.util.Base64.decode(image_data, android.util.Base64.DEFAULT); Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
			ImageView image = img;
			image.setImageBitmap(decodedByte);
		} catch (Exception e) {
 
		}
		
	}
	public void readComment(String p, TextView tv) 
	{    
		StringBuilder stringBuilder = new StringBuilder();
		try {
			BufferedReader bufferedReader = new BufferedReader(new FileReader(p));
			String line;
			while ((line = bufferedReader.readLine()) != null) {
				stringBuilder.append(line);
				stringBuilder.append('\n');
			}
			bufferedReader.close();
		} catch (IOException e) {

		}

		try{  
			JSONObject reader = new JSONObject(stringBuilder.toString());
			text_data = reader.getString("cm");
		}catch(Exception e)
		{}
		TextView text = tv;
		text.setText(text_data);
	}
	public void readImage(String p, ImageView img) 
	{    
		StringBuilder stringBuilder = new StringBuilder();
		try {
			BufferedReader bufferedReader = new BufferedReader(new FileReader(p));
			String line;
			while ((line = bufferedReader.readLine()) != null) {
				stringBuilder.append(line);
				stringBuilder.append('\n');
			}
			bufferedReader.close();
		} catch (IOException e) {

		}

		try{  
			JSONObject reader = new JSONObject(stringBuilder.toString());
			image_data = reader.getString("data");
		}catch(Exception e)
		{}
		try{
			byte[] decodedString = android.util.Base64.decode(image_data, android.util.Base64.DEFAULT); Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
			ImageView image = img;
			image.setImageBitmap(decodedByte);
		} catch (Exception e) {

		}

	}
	public static String getComment(String p) 
	{    
		StringBuilder stringBuilder = new StringBuilder();
		try {
			BufferedReader bufferedReader = new BufferedReader(new FileReader(p));
			String line;
			while ((line = bufferedReader.readLine()) != null) {
				stringBuilder.append(line);
				stringBuilder.append('\n');
			}
			bufferedReader.close();
		} catch (IOException e) {

		}

		try{  
			JSONObject reader = new JSONObject(stringBuilder.toString());
			text_data = reader.getString("cm");
		}catch(Exception e)
		{}
		return text_data;

	}
	public static Bitmap getImage(String p) 
	{    
		StringBuilder stringBuilder = new StringBuilder();
		try {
			BufferedReader bufferedReader = new BufferedReader(new FileReader(p));
			String line;
			while ((line = bufferedReader.readLine()) != null) {
				stringBuilder.append(line);
				stringBuilder.append('\n');
			}
			bufferedReader.close();
		} catch (IOException e) {

		}

		try{  
			JSONObject reader = new JSONObject(stringBuilder.toString());
			image_data = reader.getString("data");
		}catch(Exception e)
		{}
		try{
			byte[] decodedString = android.util.Base64.decode(image_data, android.util.Base64.DEFAULT); Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
			
			bitmap_data = decodedByte;
		} catch (Exception e) {

		}
   return bitmap_data;
	}
}


