package dm.li;

import android.app.*;
import android.os.*;
import android.widget.*;
import org.json.*;
import com.dm.library.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		ImageView image;
		TextView text;
		image = (ImageView) findViewById(R.id.Imageview1);
		text = (TextView) findViewById(R.id.textview1);
		
		
		
		String path = "/storage/emulated/0/dmFile/HR.dm";
		
		
		dmfile dm = new dmfile();
		   
			dm.readDmfile(path,text,image);
			
			/* 2
			dm.readComment( path , text);
			*/
			/* 3
			dm.readImage( path , image);
			*/
			/* 4
			text.setText( dm.getComment(path));
			*/
			/* 5
			image.setImageBitmap( dm.getImage(path));
			*/
    }
}
